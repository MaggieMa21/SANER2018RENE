//Copyright 2006 Stephane GINER
//
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.

package fr.expression4j.core.impl;

import java.util.HashMap;
import java.util.Map;

import fr.expression4j.basic.MathematicalElement;
import fr.expression4j.core.Parameters;
import fr.expression4j.core.exception.ParametersException;

/**
 * Implementation of parameters interface.
 * @author SGINER
 *
 */
public class ParametersImpl implements Parameters {

	private Map parameters;
	
	/**
	 * Construct an empty parameters.
	 *
	 */
	public ParametersImpl() {
		super();
		parameters = new HashMap(3);
	}

	/* (non-Javadoc)
	 * @see fr.expression4j.core.Parameters#addParameter(java.lang.String, double)
	 */
	public void addParameter(String name, MathematicalElement value) {
		parameters.put(name,value);
	}

	/* (non-Javadoc)
	 * @see fr.expression4j.core.Parameters#addParameters(java.util.Map)
	 */
	public void addParameters(Map parameters) {
		this.parameters.putAll(parameters);

	}

	/* (non-Javadoc)
	 * @see fr.expression4j.core.Parameters#addParameters(fr.expression4j.core.Parameters)
	 */
	public void addParameters(Parameters parameters) {
		this.parameters.putAll(parameters.getParameters());
	}

	/* (non-Javadoc)
	 * @see fr.expression4j.core.Parameters#getParameter(java.lang.String)
	 */
	public MathematicalElement getParameter(String name) throws ParametersException {
		MathematicalElement value = (MathematicalElement) parameters.get(name);
		if (value == null) {
			throw new ParametersException("Parameter " + name + " not found.");
		}
		
		return value;
	}

	/* (non-Javadoc)
	 * @see fr.expression4j.core.Parameters#getParameters()
	 */
	public Map getParameters() {
		return parameters;
	}

}
