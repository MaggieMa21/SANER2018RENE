CS3343-Cal
==========

A simple JAVA calculator



### Automation Build Status - master branch
[![Build Status](https://travis-ci.org/shinypichu88/CS3343-Cal.svg?branch=master)](https://travis-ci.org/shinypichu88/CS3343-Cal)

### Automation Build Status - develop branch
[![Build Status](https://travis-ci.org/shinypichu88/CS3343-Cal.svg?branch=develop)](https://travis-ci.org/shinypichu88/CS3343-Cal)
